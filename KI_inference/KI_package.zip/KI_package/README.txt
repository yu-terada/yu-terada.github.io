Package for inference of neuronal networks using kinetic Ising model (Ver. 0.2)
Author:
Yu Terada <yu.terada@riken.jp> (RIKEN CBS)
Date: Sep. 5, 2018

How to use KIpackage
Index

I. Demo
1. Hodgkin-Huxley simulation: demo/hh_network.m
2. Calculation of the optimal value for time bins: demo/decision_bin_size.m
3. Inference of Coupling Network: demo/inference.m

II. Application to Your Data
4. Calculation of the optimal value for time bins for Your Data: decision_bin_size_data.m
5. Inference of Coupling Network for Your Data: inference_data.m

III. Operation Check
6. Tested environment


1. Hodgkin-Huxley Simulation: hh_network.m
==========================================
To generate simulated data for testing, you can use 'hh_network.m'.
This yields 100 neuronal firing data with T = 1 000 000 and dt =0.01.
It is time-consuming (roughly a few hours), therefore we have prepared previously the spike train data named  'hodgkinhuxley_chain_K_0.015_T_1000000.txt' and coupling matrix data named 'hodgkinhuxley_chain_K_0.015_T_1000000_condition.txt'.
Hence, you can skip this step, if you download them.


2. Calculation of Optimal Value for Time Bins: decision_bin_size.m
==================================================================
From the spike train data, you can find an optimal size for time bins using our method.
The output time width is rounded to an integer.
This may take roughly a few hours.


3. Inference of Coupling Network: inference.m
=============================================
From the spike train data, we infer neuronal couplings using our method.
In the example with the HH model, we compare the estimates with the ground truth.
This procedure may take roughly just a few minutes.



4. Calculation of the optimal value for time bins for Your Data: decision_bin_size_data.m
================================================================
From your spike data, you can estimate the optimal value of the time bins for next inference step.
What you should prepare is the data described as the one of the HH model, that is:
$neuronal index  $spike time
.             .
.             .
.             .


5. Inference of Coupling Network for Your Data: inference_data.m
================================================================
From your spike data, you can infer couplings based on our method.
As in step 4 it would be better for preparing the data described as:
$neuronal index  $spike time
.             .
.             .
.             .

We note that you can change the value for time bin size manually to get better estimates.



6. Tested environment
=====================
Environment 1
Spec: MacBook Pro
OS: Mac OS High Sierra
Matlab: R2018a


* Reference

Y. Terada, T. Obuchi, T. Isomura and Y. Kabashima,
"Objective and efficient inference for couplings in neuronal networks",
[arXiv:1805.07061] (accepted in NIPS 2018).

Y. Terada, T. Obuchi, T. Isomura and Y. Kabashima,
"Objective Procedure for Reconstructing Couplings in Complex Systems",
[arXiv:1803.04738].