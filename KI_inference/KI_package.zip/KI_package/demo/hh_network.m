clear all;
clf;

NUM_NEURONS = 100;
TIME_END = 1000000;
dt = 0.01; 
NUM_POISSON = NUM_NEURONS;
intensity_posisson = 0.18;
k_delta = 2;
strength = 0.015;
num_inh = 10;
strength_inh = 2;
threshold = 30;

s = RandStream('mt19937ar','Seed',7493021);
RandStream.setGlobalStream(s);

voltage = randn(1,NUM_NEURONS);
gate_n = rand(1,NUM_NEURONS);
gate_m = rand(1,NUM_NEURONS);
gate_h = rand(1,NUM_NEURONS);
dn = zeros(1,NUM_NEURONS);
dm = zeros(1,NUM_NEURONS);
dh = zeros(1,NUM_NEURONS);
J = zeros(NUM_NEURONS,NUM_NEURONS);
dv = zeros(1,NUM_NEURONS);

for i=1:NUM_NEURONS-3
   J(i+1,i) = strength*(rand+1);
   J(i+2,i) = strength*(rand+1);
   J(i+3,i) = strength*(rand+1);
end
J(NUM_NEURONS,NUM_NEURONS-2) = strength*(rand+1);
J(NUM_NEURONS,NUM_NEURONS-1) = strength*(rand+1);
J(NUM_NEURONS-1,NUM_NEURONS-2) = strength*(rand+1);
J(1,NUM_NEURONS-2) = strength*(rand+1);
J(1,NUM_NEURONS-1) = strength*(rand+1);
J(1,NUM_NEURONS) = strength*(rand+1);
J(2,NUM_NEURONS-1) = strength*(rand+1);
J(2,NUM_NEURONS) = strength*(rand+1);
J(3,NUM_NEURONS) = strength*(rand+1);
tmp = randperm(NUM_NEURONS);
for i=1:num_inh
    if tmp(i) < NUM_NEURONS-2
        J(tmp(i)+1,tmp(i)) = -strength_inh*strength*(rand+1);
        J(tmp(i)+2,tmp(i)) = -strength_inh*strength*(rand+1);
        J(tmp(i)+3,tmp(i)) = -strength_inh*strength*(rand+1);
    elseif tmp(i) == NUM_NEURONS-2
        J(tmp(i)+2,tmp(i)) = -strength_inh*strength*(rand+1);
        J(tmp(i)+1,tmp(i)) = -strength_inh*strength*(rand+1);
        J(1,tmp(i)) = -strength_inh*strength*(rand+1);
    elseif tmp(i) == NUM_NEURONS-1
        J(tmp(i)+1,tmp(i)) = -strength_inh*strength*(rand+1);
        J(1,tmp(i)) = -strength_inh*strength*(rand+1);
        J(2,tmp(i)) = -strength_inh*strength*(rand+1);
    else
        J(1,tmp(i)) = -strength_inh*strength*(rand+1);
        J(2,tmp(i)) = -strength_inh*strength*(rand+1);
        J(3,tmp(i)) = -strength_inh*strength*(rand+1);
    end
end

prename = 'hodgkinhuxley_chain_K_'; 
postname1 = '_T_';
postname2 = '_condition';
postname3 = '.txt';
filename1 = [prename, num2str(strength), postname1, num2str(TIME_END), postname2, postname3];

fileID = fopen(filename1,'w');
fprintf(fileID,'\n');
for i=1:NUM_NEURONS
    for j=1:NUM_NEURONS
        fprintf(fileID,'%d %d %f\n',i,j,J(i,j));
    end
end
fclose(fileID);

index = 0;
index2 =0;
I = 1.5*ones(1,NUM_NEURONS);

filename2 = [prename, num2str(strength), postname1, num2str(TIME_END), postname3];
fileID = fopen(filename2,'w');

for t = 0:dt:TIME_END
    index = index+1;
    
    state_poisson = zeros(1,NUM_POISSON);
    for i = 1:NUM_POISSON
        if rand < intensity_posisson*dt
            state_poisson(i) = 1;
        end
    end
    
    M = gate_m.^3;
    N = gate_n.^4;
    coupling = J*(voltage.*(voltage > threshold))'+k_delta*state_poisson'/dt;
    for i = 1:NUM_NEURONS
        dv(i) = coupling(i)+I(i)-120*M(i)*gate_h(i)*(voltage(i)-120)-36*N(i)*(voltage(i)+12)-0.3*(voltage(i)-10.6);
        dn(i) = (0.01*(10-voltage(i))/(exp((10-voltage(i))/10)-1))*(1-gate_n(i))-0.125*exp(-voltage(i)/80)*gate_n(i);
        dm(i) = (0.1*(25-voltage(i))/(exp((25-voltage(i))/10)-1))*(1-gate_m(i))-4*exp(-voltage(i)/18)*gate_m(i);
        dh(i) = 0.07*exp(-voltage(i)/20)*(1-gate_h(i))-gate_h(i)/(exp((30-voltage(i))/10)+1);
    end
    old_voltage = voltage;
    voltage = voltage + dv*dt;
    gate_m = gate_m + dm*dt;
    gate_h = gate_h + dh*dt;
    gate_n = gate_n + dn*dt;
    
    if t<4500
        v_history(:,index) = voltage;
    end
    for i = 1:NUM_NEURONS
       if (old_voltage(i)-30)*(voltage(i)-threshold)<0 && voltage(i)>threshold 
           fprintf(fileID,'%d %f\n',i,t);
           if t < 3000
            index2 = index2+1;
            firings(index2,:) = [t,i];
           end
       end
    end
end
fclose(fileID);

postname4 = '.eps';
figure(1);
plot(firings(:,1),firings(:,2),'.k');
xlabel('time [ms]')
ylabel('neuron')
xlim([0 3000])
drawnow;
prename3 = 'spikes_';
filename4 = [prename3,prename, num2str(strength), postname1, num2str(TIME_END),postname4];
saveas(gcf,filename4,'epsc')