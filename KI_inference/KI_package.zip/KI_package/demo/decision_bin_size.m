clear all;
clf;

TIME_LENGTH = 1000000;
NUM_OF_NEURON = 100;
dt = 0.5;
x = zeros(NUM_OF_NEURON,fix(TIME_LENGTH/dt));
x(:,:) = 0;

filename = 'hodgkinhuxley_chain_K_0.015_T_1000000.txt';
delimiterIn = ' ';
headerlinesIn = 1;
A = importdata(filename,delimiterIn,headerlinesIn);
num_spikes = size(A.data,1);
spike_time = 0;

for spike_index=1:num_spikes
    spike_time = A.data(spike_index,2);
    neuron_index = A.data(spike_index,1);
    if spike_time < ceil(TIME_LENGTH/dt)+1 && ceil(spike_time/dt) > 0
        x(neuron_index,ceil(spike_time/dt)) = 1;
    end
end

window_length = 0;
expansion_rate=1.1;
for coarse_index=1:50
    window_length = expansion_rate^(coarse_index-1);
    window_msecond(coarse_index) = window_length*dt;
    num_window = fix(TIME_LENGTH/window_msecond(coarse_index));
    coarsed_x = zeros(NUM_OF_NEURON,num_window);
    coarsed_x(:,:) = 0;
    for i=1:NUM_OF_NEURON
        for window_index=0:(num_window-1)
            flag = 0;
            for j=fix(1+window_index*window_length):fix((window_index+1)*window_length)
                flag = flag+x(i,j);
            end
            if flag>1/(2+window_length)
                coarsed_x(i,window_index+1) = 1;
            end
        end
    end
    for i=1:NUM_OF_NEURON
        for j=1:NUM_OF_NEURON
            p_joint = zeros(2,2);
            p_i(1) = 0;
            p_i(2) = 0;
            p_j(1) = 0;
            p_j(2) = 0;
            n_joint = zeros(2,2);
            for window_index=1:(num_window-1)
               if  (coarsed_x(i,window_index)<0.5) && (coarsed_x(j,window_index+1)<0.5)
                   p_joint(1,1) = p_joint(1,1)+1/(num_window-1);
                   p_i(1) = p_i(1)+1/(num_window-1);
                   p_j(1) = p_j(1)+1/(num_window-1);
                   n_joint(1,1) = n_joint(1,1)+1;
               elseif (coarsed_x(i,window_index)>0.5) && (coarsed_x(j,window_index+1)<0.5)
                   p_joint(2,1) = p_joint(2,1)+1/(num_window-1);
                   p_i(2) = p_i(2)+1/(num_window-1);
                   p_j(1) = p_j(1)+1/(num_window-1);
                   n_joint(2,1) = n_joint(2,1)+1;
               elseif (coarsed_x(i,window_index)<0.5) && (coarsed_x(j,window_index+1)>0.5)
                   p_joint(1,2) = p_joint(1,2)+1/(num_window-1);
                   p_i(1) = p_i(1)+1/(num_window-1);
                   p_j(2) = p_j(2)+1/(num_window-1);
                   n_joint(1,2) = n_joint(1,2)+1;
               elseif (coarsed_x(i,window_index)>0.5) && (coarsed_x(j,window_index+1)>0.5)
                   p_joint(2,2) = p_joint(2,2)+1/(num_window-1);
                   p_i(2) = p_i(2)+1/(num_window-1);
                   p_j(2) = p_j(2)+1/(num_window-1);
                   n_joint(2,2) = n_joint(2,2)+1;
               end
            end
            
            mi_ij(i,j) = 0;
            if p_joint(1,1)*p_i(1)*p_j(1)>0
                mi_ij(i,j) = p_joint(1,1)*log(p_joint(1,1)/(p_i(1)*p_j(1)));
            end
            if p_joint(2,1)*p_i(2)*p_j(1)>0
                mi_ij(i,j) = mi_ij(i,j)+p_joint(2,1)*log(p_joint(2,1)/(p_i(2)*p_j(1)));
            end
            if p_joint(1,2)*p_i(1)*p_j(2)>0
                mi_ij(i,j) = mi_ij(i,j)+p_joint(1,2)*log(p_joint(1,2)/(p_i(1)*p_j(2)));
            end
            if p_joint(2,2)*p_i(2)*p_j(2)>0
                mi_ij(i,j) = mi_ij(i,j)+p_joint(2,2)*log(p_joint(2,2)/(p_i(2)*p_j(2)));
            end
            if i== j
                mi_ij(i,j) = 0;
            end
        end
    end
    mi_sum(coarse_index) = 0;
    tmp = mean(mi_ij);
    mi_sum(coarse_index) = (num_window-1)*mean(tmp,2)*NUM_OF_NEURON/(NUM_OF_NEURON-1);    
end

figure(1);
semilogx(window_msecond,mi_sum,'-ro','LineWidth',2,'MarkerSize',10);
drawnow
xlabel('Delta tau [ms]')
title('Gross Mutual Information')
prename = 'hodgkinhuxley_network_T_'; 
postname = '.eps';
filename1 = [prename, num2str(TIME_LENGTH), postname];
saveas(gcf,filename1,'epsc')

[M,I] = max(mi_sum(:));
optimal_binsize = round(expansion_rate^(I-1)*dt)