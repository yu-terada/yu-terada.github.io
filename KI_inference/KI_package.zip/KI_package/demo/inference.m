clear all;
clf;

%%%%% insert the optimal value for time bins here!           %%%%%%
%%%%% you can change the value manually for better inference %%%%%%
window_msecond = 3;
window_length = window_msecond;

%%%%% this is the level of siginificance %%%%%
alpha = 1e-3;

TIME_LENGTH = 1000000;
NUM_OF_NEURON = 100;
x = zeros(NUM_OF_NEURON,TIME_LENGTH);
x(:,:) = -1;

filename = 'hodgkinhuxley_chain_K_0.015_T_1000000.txt';
delimiterIn = ' ';
headerlinesIn = 1;
A = importdata(filename,delimiterIn,headerlinesIn);
num_spikes = size(A.data,1);
spike_time = 0;

for spike_index=1:num_spikes
    spike_time = A.data(spike_index,2);
    neuron_index = A.data(spike_index,1);
    if spike_time < (TIME_LENGTH+1) && fix(spike_time) > 0
        x(neuron_index,fix(spike_time)) = 1;
    end
end

num_window = fix(TIME_LENGTH/window_length);
coarsed_x = zeros(NUM_OF_NEURON,num_window);
coarsed_x(:,:) = -1;
for i=1:NUM_OF_NEURON
    for window_index=0:(num_window-1)
        flag = 0;
        for j=(1+fix(window_index*window_length)):(fix((window_index+1)*window_length))
            flag = flag+x(i,j);
        end
        if flag>(-window_length)
            coarsed_x(i,window_index+1)=1;
        end
    end
end

m = mean(coarsed_x,2);
delta_x_history = zeros(NUM_OF_NEURON,num_window);
for i=1:NUM_OF_NEURON
   for window_index=1:num_window
    delta_x_history(i,window_index) = coarsed_x(i,window_index)-m(i);
   end
end

C = delta_x_history*(delta_x_history)'/num_window;
tmp = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        for window_index=2:num_window
            tmp(i,j) = tmp(i,j)+delta_x_history(i,window_index)*delta_x_history(j,window_index-1);
        end
        tmp(i,j) = tmp(i,j)/(num_window-1);
    end
end
D = tmp;
E = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
for i=1:NUM_OF_NEURON
    E(i,i) = 1-m(i)*m(i);
end
J_est = inv(E)*D*inv(C);

tmp2 = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        tmp2(i,j) = sqrt(2.0/((1-m(i)*m(i))*(1-m(j)*m(j))*(num_window-1)));
    end
end
Phi_threshold = erfinv(1-alpha)*tmp2;

K_est = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
J_est_screen = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        if abs(Phi_threshold(i,j)) < abs(J_est(i,j))
            if J_est(i,j)>0
            K_est(i,j) = 1;
            end
            if J_est(i,j)<0
            K_est(i,j) = -1;
            end
            J_est_screen(i,j) = J_est(i,j);
        end
    end
end

figure(1);
image(K_est,'CDataMapping','scaled')
axis square
map = [0, 0, 1
    1, 1, 1
    1, 0, 0];
colormap(map);
title('Inferred Network')
drawnow;
prename = 'hodgkinhuxley_chain_K_0.015_T_'; 
postname1 = '_inference_tau_';
postname2 = 'ms.eps';
filename1 = [prename, num2str(TIME_LENGTH), postname1, num2str(window_msecond), postname2];
saveas(gcf,filename1,'epsc')

filename = 'hodgkinhuxley_chain_K_0.015_T_1000000_condition.txt';
delimiterIn = ' ';
headerlinesIn = 1;
A = importdata(filename,delimiterIn,headerlinesIn);
 
J_real = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        J_real(i,j) = A(NUM_OF_NEURON*(i-1)+j,3);
    end
end
K_real = zeros(NUM_OF_NEURON,NUM_OF_NEURON);
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        if J_real(i,j)>0
           K_real(i,j) = 1;
        end
        if J_real(i,j)<0
            K_real(i,j) = -1;
        end
    end
end
figure(2);
image(K_real,'CDataMapping','scaled')
axis square
map = [0, 0, 1
    1, 1, 1
    1, 0, 0];
colormap(map);
title('Ground Truth')
drawnow;
postname3 = '_groud_truth_tau_';
filename2 = [prename, num2str(TIME_LENGTH), postname3, num2str(window_msecond), postname2];
saveas(gcf,filename2,'epsc')

J_est_screen_vec = [];
J_real_vec = [];
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        if i ~= j
            J_est_screen_vec = [J_est_screen_vec,J_est_screen(i,j)];
            J_real_vec = [J_real_vec,J_real(i,j)];
        end
    end
end
figure(3);
plot(J_real_vec,J_est_screen_vec,'r.','MarkerSize',10)
xlabel('Coupling Strength in HH model')
ylabel('Estimates in kinetic Ising model')
title('Real Couplings vs Inferred Couplings')
drawnow;
postname4 = '_truth_vs_estimates_tau_';
filename3 = [prename, num2str(TIME_LENGTH), postname4, num2str(window_msecond), postname2];
saveas(gcf,filename3,'epsc')

true_positive = 0;
false_positive = 0;
false_negative = 0;
true_negative = 0;
excitory_correct = 0;
inhibitory_correct = 0;
norm_ex = 0;
norm_in = 0;
for i=1:NUM_OF_NEURON
    for j=1:NUM_OF_NEURON
        if i~=j
            if abs(J_real(i,j))>0 && abs(K_est(i,j))>0
               true_positive = true_positive+1/(NUM_OF_NEURON*(NUM_OF_NEURON-1));
               if J_real(i,j)>0
                  excitory_correct = excitory_correct+1;
               end
               if J_real(i,j)<0
                  inhibitory_correct = inhibitory_correct+1;
               end
            elseif J_real(i,j)==0 && K_est(i,j)==0
               true_negative = true_negative+1/(NUM_OF_NEURON*(NUM_OF_NEURON-1));
            elseif abs(J_real(i,j))>0 && K_est(i,j)==0
               false_negative = false_negative+1/(NUM_OF_NEURON*(NUM_OF_NEURON-1));
            elseif J_real(i,j)==0 && abs(K_est(i,j))>0
                false_positive = false_positive+1/(NUM_OF_NEURON*(NUM_OF_NEURON-1));
            end
            if J_real(i,j)>0
                norm_ex = norm_ex+1;
            end
            if J_real(i,j)<0
                norm_in = norm_in+1;
            end
        end
    end
end
p_ex = excitory_correct/norm_ex;
p_in = inhibitory_correct/norm_in;
sensitivity = true_positive/(true_positive+false_negative);
specificity = true_negative/(false_positive+true_negative);
 for i=1:4
     index_vec(i) = i; 
 end
rate(1) = sensitivity;
rate(2) = specificity; 
rate(3) = p_ex;
rate(4) = p_in;
figure(4);
plot(index_vec(:),rate(:),'-ro','LineWidth',2,'MarkerSize',10)
title('Accuracy Rate')
xticks([1 2 3 4])
xticklabels({'Exitence','Absence','Excitatory','Inhibitory'})
axis([1 4 0 1])
drawnow
prename3 = 'accuracy_rate_';
postname5 = '_accuracy_rate_tau_';
filename4 = [prename, num2str(TIME_LENGTH), postname5, num2str(window_msecond), postname2];
saveas(gcf,filename4,'epsc')